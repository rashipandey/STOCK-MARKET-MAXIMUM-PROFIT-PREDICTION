Instructions to run this file:

1. Run command 'make'. This will compile our files are make it ready for execution
2. Run command 'java Stocks TASK_NAME_HERE' to run our program.
3. Give space separated values in format as given in test cases(on canvas)